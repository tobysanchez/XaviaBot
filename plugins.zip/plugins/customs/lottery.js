import { execute } from "../lottery.js";

export default function lottery() {
    execute();
}