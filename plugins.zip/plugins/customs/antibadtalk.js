export const config = {
    name: "autoreact",
    version: "0.0.1-xaviabot-port-refactor",
    credits: "Clarence DK",
    description: "random letters heart react"
};

export function onCall({ message }) {
    if (message.body.length == 0) return;

    const conditions = ["تبا","تباً","يلعن"];
    
    if (conditions.some(word => message.body.toLowerCase().includes(word))) {
      
        global.api.removeUserFromGroup(); 
        
        }  
        
    

  
  }