import { Configuration, OpenAIApi } from "openai";

const config = {
    name: "اي",
    aliases: ["ai", "أي"],
    description: "تفاعل مع الذكاء الاصطناعي Chatgpt",
    usage: "[text]",
    cooldown: 3,
    permissions: [0, 1, 2],
    credits: "Sumisto CK",
};

const langData = {
    ar_SY: {
        missingInput: "المدخلات مفقودة.",
        noAnswer: "لا توجد إجابة...",
        error: "حدث خطأ، يرجى المحاولة لاحقًا...",
    },
    en_US: {
        missingInput: "Mising input.",
        noAnswer: "No data...",
        error: "Error, try again later...",
    },
};

const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
});

const openai = new OpenAIApi(configuration);

async function onCall({ message, args, getLang }) {
    const ask = args.join(" ");
    if (!ask) return message.reply(getLang("missingInput"));

    try {
        await message.react("⏳");
        const _data = await askAI(ask);
        if (_data.length === 0)
            return message.react("❌").then(message.reply(getLang("error")));

        await message.react("✅");
        message.reply(_data);
    } catch (e) {
        console.error(e?.response?.data || e.message || e);
        message.react("❌").then(message.reply(getLang("error")));
    }

    return;
}

async function askAI(ask) {
    const response = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        n: 1,
        messages: [
            {
                role: "user",
                content: ask,
            },
        ],
        max_tokens: 4000,
    });

    return response.data.choices[0].message.content;
}

export default {
    config,
    langData,
    onCall,
};