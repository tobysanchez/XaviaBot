const config = {
    name: "المطور",
    aliases: ["code", "about"],
    description: "معلومات المطور"
}

const langData = {
    "en_US": {
        "details": "A Bot Messenger running on NodeJS:\n{source}"
    },
    "vi_VN": {
        "details": "Bot Messenger chạy trên NodeJS:\n{source}"
    },
    "ar_SY": {
        "details": "بوت من تعديل وتطوير 𝐓𝐎𝐁𝐘 𝐒𝐀𝐍𝐂𝐇𝐄𝐙:\n{source}"
    }
}

const source = "www.facebook.com/profile.php?id=100083663902597";
function onCall({ message, getLang }) {
    message.reply(getLang("details", { source }));
}

export default {
    config,
    langData,
    onCall
}
