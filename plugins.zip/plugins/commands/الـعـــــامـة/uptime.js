const config = {
    name: "ابتايم",
    aliases: ["upt"],
    credits: "𝐓𝐎𝐁𝐘 𝐒𝐀𝐍𝐂𝐇𝐄𝐙"
}

function onCall({ message }) {
    let uptime = global.msToHMS(process.uptime() * 1000);
    message.reply(uptime);
}


export default {
    config,
    onCall
}
