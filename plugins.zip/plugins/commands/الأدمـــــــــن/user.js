const config = {
    name: "عضو",
    description: "ban/unban a user",
    version: "0.0.1-beta",
    usage: "[tag/reply]",
    cooldown: 3,
    permissions: [1, 2],
    credits: "𝐓𝐎𝐁𝐘 𝐒𝐀𝐍𝐂𝐇𝐄𝐙"
}

const langData = {
    "ar_SY": {
        "missingTarget": "تاق أو رد على رسالة المطلوب حظره..",
        "noData": "لا توجد بيانات...",
        "success": "تم حظر العضو بنجاح!",
        "success2":"تم فك الحظر العضو بنجاح!",
        "error": "حدث خطأ. "
    },
    "en_US": {
        "missingTarget": "Please tag/Reply to a user that you want to ban.",
        "noData": "No data available...",
        "success": "Success!",
        "error": "error"
    }
}

async function onCall({ message, args, getLang, data }) {
    try {
        const { mentions, messageReply, type } = message;
        const query = args[0]?.toLowerCase();
        if (query != "بان" && query != "فك") return;

        const targetIDs =
            Object.keys(mentions).length > 0 ? Object.keys(mentions) :
                type == "message_reply" ? [messageReply.senderID] : null;

        if (!targetIDs) return message.reply(getLang("missingTarget"));

        const members = data?.thread?.info?.members;
        if (!members) return message.reply(getLang("noData"));

        if (query == "بان") {
            for (const id of targetIDs) {
                if (members.find(e => e.userID == id))
                    members.find(e => e.userID == id).banned = true;
            }  global.controllers.Threads.updateInfo(message.threadID, { members });
        message.reply(getLang("success"));
        } else {
            for (const id of targetIDs) {
                if (members.find(e => e.userID == id))
                    members.find(e => e.userID == id).banned = false;
            }
          global.controllers.Threads.updateInfo(message.threadID, { members });
          message.reply(getLang("success2"));
        }

        
        
    } catch (e) {
        console.error(e);
        message.reply(getLang("error"));
    }
}

export default {
    config,
    langData,
    onCall
}
