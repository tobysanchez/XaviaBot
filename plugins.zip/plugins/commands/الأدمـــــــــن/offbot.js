const config = {
    name: "ايقاف",
    aliases: ["إيقاف", "نوم"],
    permissions: [2],
    isAbsolute: true
}

async function onCall({ message, getLang }) {
    await message.reply("اااه نعسانة تصبحو علي خير🐥🥱");
    global.shutdown();
}

export default {
    config,
    onCall,
    getLang
  }