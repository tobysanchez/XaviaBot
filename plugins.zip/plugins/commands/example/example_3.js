// no config provided so will use default config
// with name will be the file name

export default function ({ message, args, getLang, extra, data, userPermissions, prefix }) {
    // code here
}
