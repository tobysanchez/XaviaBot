en_US
this is an Example category & plugins

vi_VN
Đây là một ví dụ về danh mục & plugins
