const config = {
    name: "داير بانكاي؟ ",
    credits: "عمك توبي غيرة منو؟ ",
    description: "تشرح بيها السان",
    usage: "تاق ولا رد ",
    permissions: [1,2],
    cooldown: 5
}

const imagesURL = [

  ];

const cost = BigInt(500);
async function onCall({ message, args }) {
    const { senderID, reply } = message;

    try {
        const imageStream = await global.getStream(imagesURL[Math.floor(Math.random() * imagesURL.length)]);

        return reply({
          body: "بااااااااااانكايييييي",
          attachment: [imageStream]
        });
    } catch (e) {
        console.error(e);
        return reply("error");
    }
}

export default {
    config,
    onCall
}







