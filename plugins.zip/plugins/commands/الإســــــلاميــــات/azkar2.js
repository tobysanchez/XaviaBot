export const config = {
    name: "أذكار2",
    description: "لا تنس ذكر الله", 
    usage: "",
    cooldown: 3,
    permissions: [0, 1, 2],
    credits: "لوجه الله تعالى ",
}

export const MORNING = [
    "أصبحنا و أصبح الملك لله.",
    "لا تنسو صلاة الصبح و أكثروا من الاستغفار. ",
];
export const AFTERNOON = [
    "اللهم صل و سلم على نبينا محمد ﷺ 🌺",
    "لا تنسوا صلاة الظهر! ",
];
export const EVENING = [
    "اللهم أعنا على طاعتك و جنبنا معصيتك 🤲",
    "صلوا على من لا نبي بعده سيدنا محمد ﷺ",
];
export const NIGHT = [
    "استغفرالله الله العظيم و أتوب اليه 🤲🌺",
    "سبحان الله و بحمده سبحان الله العظيم ✨",
];

export async function onCall({ message }) {
    switch (getTime()) {
        case 1: return message.reply(MORNING[Math.floor(Math.random() * MORNING.length)]);
        case 2: return message.reply(AFTERNOON[Math.floor(Math.random() * AFTERNOON.length)]);
        case 3: return message.reply(EVENING[Math.floor(Math.random() * EVENING.length)]);
        case 4: return message.reply(NIGHT[Math.floor(Math.random() * NIGHT.length)]);
    }
}

export function getTime() {

const time = new Date().toLocaleString("ar-SY", { timeZone: global.config.timezone || "Africa/Khartoum" });
  
   /* const time = new Date().toLocaleString("ar-SY", { timeZone: global.config.timezone });*/
    const hour = new Date(time).getHours();

    if (hour >= 5 && hour < 12) return 1;
    if (hour >= 12 && hour < 18) return 2;
    if (hour >= 18 && hour < 22) return 3;
    if (hour >= 22 || hour < 5) return 4;

    return 1;
  }