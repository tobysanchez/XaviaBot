export default function ({ message }) {
    global.random(0, 5) === 3 ? message.reply("بحبك يا باكا  >w<") : message.reply("معليش نحن اصحاب بس 😔");
}
