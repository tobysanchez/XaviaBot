const config = {
  name: "قط",
  description: "Generates a cat meme with the provided text",
  usage: "[text]",
  cooldown: 3,
  permissions: [0, 1, 2],
  credits: "𝐓𝐎𝐁𝐘 𝐒𝐀𝐍𝐂𝐇𝐄𝐙"
};

const langData = {
  "vi_VN": {
    "missingInput": "Bạn chưa nhập dữ liệu",
    "error": "Có lỗi xảy ra, vui lòng thử lại sau"
  },
  "en_US": {
    "missingInput": "You haven't entered any text",
    "error": "An error occurred, please try again later"
  },
  "ar_SY": {
    "missingInput": "لم تدخل أي نص",
    "error": "لقد حدث خطأ، رجاء أعد المحاولة لاحقا"
  }
};

async function onCall({ message, args, getLang }) {
  const input = args.join(" ");
  if (input.length == 0) return message.reply(getLang("missingInput"));

  global
    .getStream(`https://cataas.com/cat/says/${encodeURIComponent(input)}`)
    .then(stream => {
      message.reply({ attachment: stream });
    })
    .catch(err => {
      console.error(err);
      message.reply(getLang("error"));
    });
}

export default {
  config,
  langData,
  onCall
};