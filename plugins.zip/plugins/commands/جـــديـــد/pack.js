const config = {

    name: "حزمة",

    aliases: ["KONOW_PACK"],

    description: "حزمة فيها كل ما يحتاجه المصمم",

    usage: "",

    credits: "𝐓𝐎𝐁𝐘 𝐒𝐀𝐍𝐂𝐇𝐄𝐙"

}

async function onCall({
    message,
    args
}) {



    let data = [

        {

            "Name": "●▬▬๑۩ KONOW PACK۩๑▬▬●\nحزمة خارقة لكل مصمم\nتحتوي علي\n》=خطوط=《\nhttps://www.mediafire.com/file/67opgyndnbcsrjm\nhttps://www.mediafire.com/file/jjpcgh4yu0h56x6\n》=GFX PACKS=《\n1/https://www.mediafire.com/file/lpzzmq3zbnuhiob/7K_Special_AIOGP_By_Fla5h_GFX.zip/file\n2/https://www.mediafire.com/file/2muozhy9e4udlb2/Torkiz+GFX+Pack+V3.5+!+(Update).zip/file\n3/https://www.mediafire.com/file/2muozhy9e4udlb2/Torkiz+GFX+Pack+V3.5+!+(Update).zip/file?dkey=nlox8679w7y&r=451\n》= بعض روابط درايف=《\n1/https://drive.google.com/drive/folders/1N4ICGyeXjsW6DQz6kxK-Ta1vaooGRTq6\n2/https://drive.google.com/drive/folders/1v433os43Rp4GLIel3hztZDe4pTu-KGw1\n●▬▬๑۩(ﾉ≧∇≦)ﾉ۩๑▬▬●",

            "link": "https://i.imgur.com/LiN68O1.jpg",

        },

        {

            "Name": "●▬▬๑۩ KONOW PACK۩๑▬▬●\nحزمة خارقة لكل مصمم\nتحتوي علي\n》=خطوط=《\nhttps://www.mediafire.com/file/67opgyndnbcsrjm\nhttps://www.mediafire.com/file/jjpcgh4yu0h56x6\n》=GFX PACKS=《\n1/https://www.mediafire.com/file/lpzzmq3zbnuhiob/7K_Special_AIOGP_By_Fla5h_GFX.zip/file\n2/https://www.mediafire.com/file/2muozhy9e4udlb2/Torkiz+GFX+Pack+V3.5+!+(Update).zip/file\n3/https://www.mediafire.com/file/2muozhy9e4udlb2/Torkiz+GFX+Pack+V3.5+!+(Update).zip/file?dkey=nlox8679w7y&r=451\n》= بعض روابط درايف=《\n1/https://drive.google.com/drive/folders/1N4ICGyeXjsW6DQz6kxK-Ta1vaooGRTq6\n2/https://drive.google.com/drive/folders/1v433os43Rp4GLIel3h",

            "link": "https://i.imgur.com/LiN68O1.jpg"

        }

    ]

    const KONOW = data[Math.floor(Math.random() * data.length)]; //global.random(0, data.length - 1);

    global

        .getStream(KONOW.link)

        .then(stream => {

            message.send({
                body: KONOW.Name,
                attachment: stream
            });

        })
}

export default {

    config,

    onCall

}
