const config = {
    name: "رندر",
    credits: "𝐓𝐎𝐁𝐘 𝐒𝐀𝐍𝐂𝐇𝐄𝐙",
    description: "[500𝐔𝐂]الحصول علي رندر",
    usage: "",
    cooldown: 5
}

const imagesURL = [
  "https://i.imgur.com/PCPNvDW.png",
  "https://i.imgur.com/S0EvT86.jpg",
"https://i.imgur.com/S0EvT86.jpg",
  "https://i.imgur.com/bdJ5BzN.png",
  "https://i.imgur.com/65CkL8m.png",
  "https://i.imgur.com/PrnpEBW.jpg",
  "https://i.imgur.com/QTBd9tG.jpg",
  "https://i.imgur.com/Yw4On4u.jpg",
  "https://i.imgur.com/mxI1R5B.png",
  "https://i.imgur.com/TCCE9P1.jpg",
  "https://i.imgur.com/LSCVwSq.jpg",
  "https://i.imgur.com/JNxPlGC.jpg",
  "https://i.imgur.com/IuGod5W.png",
  "https://i.imgur.com/PYdsQkS.jpg",
  "https://i.imgur.com/0sHkjYU.png",
  "https://i.imgur.com/DpE5GNj.png",
  "https://i.imgur.com/QWMbRd1.jpg",
  "https://i.imgur.com/Ylm8pJa.jpg",
  "https://i.imgur.com/mj1ubvl.png",
  "https://i.imgur.com/Aw6pFXu.jpg",
  "https://i.imgur.com/7lWXeQc.jpg",
  "https://i.imgur.com/YEV4xDp.jpg",
  "https://i.imgur.com/AnDpnTH.jpg",
  "https://i.imgur.com/tDVuJ7Q.png",
  "https://i.imgur.com/1tlWSGX.jpg",
  "https://i.imgur.com/EpQzUlY.jpg",
  "https://i.imgur.com/TCDa1QS.jpg",
  "https://i.imgur.com/LlGKjdm.png",
  "https://i.imgur.com/ZVqdCd2.jpg",
  "https://i.imgur.com/CEsbObX.jpg",
  "https://i.imgur.com/JOjWoI4.jpg",
  "https://i.imgur.com/OcB82bC.jpg",
  "https://i.imgur.com/MFLjqx1.jpg",
  "https://i.imgur.com/bLSuBfm.jpg",
  "https://i.imgur.com/zvEt2O8.jpg",
  "https://i.imgur.com/SliPb0d.jpg",
  "https://i.imgur.com/QBtJaRN.jpg",
  "https://i.imgur.com/UfvfHKT.jpg",
  "https://i.imgur.com/e7YNaMD.jpg",
  "https://i.imgur.com/gjn1Srv.jpg",
  "https://i.imgur.com/9GVuBcK.jpg",
  "https://i.imgur.com/mHrk08v.jpg",
  "https://i.imgur.com/3DYmh6u.jpg",
  "https://i.imgur.com/oOvKTa0.jpg",
  "https://i.imgur.com/XjOfymp.png",
  "https://i.imgur.com/6SDmQQL.png",
  "https://i.imgur.com/mrxAV8u.png",
  "https://i.imgur.com/gvH5z14.png",
  "https://i.imgur.com/qNRbFya.png",
  "https://i.imgur.com/G3LTSA0.jpg",
  "https://i.imgur.com/QK8z0vH.jpg",
  "https://i.imgur.com/II9jhus.jpg",
  "https://i.imgur.com/dBMKuVg.jpg",
  "https://i.imgur.com/6I8yDI6.jpg",
  "https://i.imgur.com/harw7yY.jpg",
  "https://i.imgur.com/3pkYAZF.jpg",
  "https://i.imgur.com/RGok8pW.jpg",
  "https://i.imgur.com/UXDS2qm.jpg",
  "https://i.imgur.com/HDN8BSg.jpg",
  "https://i.imgur.com/NKrI3xQ.jpg",
  "https://i.imgur.com/u01Timp.jpg",
  "https://i.imgur.com/ZXP27I1.jpg",
  "https://i.imgur.com/8V7cUa5.jpg",
  "https://i.imgur.com/uWd9ejH.jpg",
"https://i.imgur.com/3FTs5nG.jpg",
  "https://i.imgur.com/UM3hd8r.jpg",
  "https://i.imgur.com/6INjvaf.jpg",
  "https://i.imgur.com/cGf9MRh.png",
  "https://i.imgur.com/XXT93dK.png",
  "https://i.imgur.com/VIWHqBu.jpg",
  "https://i.imgur.com/bsmfsRJ.jpg",
  "https://i.imgur.com/8ondGlD.png",
  "https://i.imgur.com/X9UDKHv.jpg",
  "https://i.imgur.com/GpOUsVo.jpg",
  "https://i.imgur.com/109TmQ8.png",
  "https://i.imgur.com/kJw0fmJ.jpg",
  "https://i.imgur.com/naTafDA.jpg",
  "https://i.imgur.com/jsKOPwR.jpg",
  "https://i.imgur.com/pljLILt.jpg",
  "https://i.imgur.com/pFJfSda.jpg",
  "https://i.imgur.com/f71eK5F.jpg",
  "https://i.imgur.com/p7h9PrD.png",
  "https://i.imgur.com/DjLKVwn.jpg",
  "https://i.imgur.com/wvxKDsj.png",
  "https://i.imgur.com/ayS2a8z.jpg",
  "https://i.imgur.com/n3EwMpE.jpg",
  "https://i.imgur.com/0ZGZ9Ve.jpg",
  "https://i.imgur.com/ShsbrBl.jpg",
  "https://i.imgur.com/BCWichl.jpg",
  "https://i.imgur.com/NNDMBBH.jpg",
  "https://i.imgur.com/2YhI9HW.jpg",
  "https://i.imgur.com/vjm8XC5.jpg",
  "https://i.imgur.com/KDmkEfz.png",
];

const cost = BigInt(500);
async function onCall({ message, args }) {
    const { senderID, reply } = message;

    try {
        const { Users } = global.controllers;
        const senderMoney = await Users.getMoney(senderID);
        if (senderMoney == null || BigInt(senderMoney) < cost) 
            return reply(`لا يوجد ما يكفي من المال ، أنت بحاجة الي ${cost} 𝐔𝐂.`);

        await Users.decreaseMoney(senderID, cost);

        // at this point, the money has been decreased, do some code below

        const imageStream = await global.getStream(imagesURL[Math.floor(Math.random() * imagesURL.length)]);

        return reply({
          body: "لقد اشتريت رندر مقابل 500𝐔𝐂",
          attachment: [imageStream]
        });
    } catch (e) {
        console.error(e);
        return reply("error");
    }
}

export default {
    config,
    onCall
}







